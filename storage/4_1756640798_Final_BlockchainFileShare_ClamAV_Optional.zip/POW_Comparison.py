import hashlib, random, time
def compute_hash(index, prev_hash, data_json, nonce):
    payload = f"{index}|{prev_hash or ''}|{data_json}|{nonce}".encode()
    return hashlib.sha256(payload).hexdigest()

def p_o_w(data, difficulty=3, attempts=100000):
    prefix = '0' * difficulty
    for i in range(attempts):
        nonce = random.randint(0, 99999999)
        h = compute_hash(0, '', data, nonce)
        if h.startswith(prefix):
            return nonce, h, i+1
    return None, None, attempts

def p_o_w_2(data, difficulty=3, attempts=100000):
    prefix = '0' * difficulty
    nonce = 0
    for i in range(attempts):
        h = compute_hash(0, '', data, nonce)
        if h.startswith(prefix):
            return nonce, h, i+1
        nonce += 1
    return None, None, attempts

if __name__ == '__main__':
    data='test'
    for d in [2,3,4]:
        print('Difficulty',d)
        n,h,a = p_o_w(data,d)
        print('p_o_w time done') 
        n2,h2,a2 = p_o_w_2(data,d)
        print('p_o_w_2 time done')
