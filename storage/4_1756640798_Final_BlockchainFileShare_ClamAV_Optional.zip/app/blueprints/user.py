from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file, current_app, abort
from flask_login import login_required, current_user
from ..models import User, File, Permission, Feedback, AuditLog, ShareLink, Block
from ..blockchain import append_block
from .. import db
from pathlib import Path
import hashlib, json, os, datetime, uuid, logging
from ..utils import send_email, clamav_scan

logger = logging.getLogger(__name__)

user_bp = Blueprint('user', __name__, template_folder='../templates/user')

@user_bp.before_request
def ensure_user():
    if not current_user.is_authenticated:
        return redirect(url_for('auth.login'))

@user_bp.route('/upload', methods=['GET'])
@login_required
def upload_page():
    users = User.query.filter(User.id != current_user.id).all()
    return render_template('user/upload.html', users=users)

@user_bp.route('/my_files', methods=['GET'])
@login_required
def my_files_page():
    my_files = File.query.filter_by(owner_id=current_user.id).order_by(File.created_at.desc()).all()
    users = User.query.filter(User.id != current_user.id).all()
    return render_template('user/my_files.html', my_files=my_files, users=users)

@user_bp.route('/shared', methods=['GET'])
@login_required
def shared_with_me_page():
    shared_with_me = (
        db.session.query(File)
        .join(Permission, Permission.file_id == File.id)
        .filter(Permission.grantee_id == current_user.id, Permission.revoked_at.is_(None))
        .order_by(File.created_at.desc())
        .all()
    )
    return render_template('user/shared.html', shared_with_me=shared_with_me)

@user_bp.route('/feedback', methods=['GET'])
@login_required
def feedback_page():
    return render_template('user/feedback.html')

@user_bp.route('/chain', methods=['GET'])
@login_required
def chain_page():
    blocks = Block.query.filter(Block.data_json.contains(f'"owner_id": {current_user.id}')).order_by(Block.index.desc()).limit(100).all()
    return render_template('user/chain.html', blocks=blocks)

@user_bp.post('/upload')
@login_required
def upload():
    f = request.files.get('file')
    mine_now = request.form.get('mine_now') == 'on'
    if not f or f.filename == '':
        flash('No file selected'); return redirect(url_for('user.upload_page'))
    storage_dir = Path(current_app.config['UPLOAD_FOLDER']); storage_dir.mkdir(parents=True, exist_ok=True)
    target = storage_dir / f"{current_user.id}_{int(datetime.datetime.utcnow().timestamp())}_{f.filename}"
    f.save(target)
    # perform ClamAV scan and block upload if infected or clamd unavailable
    ok, reason = clamav_scan(str(target))
    if not ok:
        # remove file and show clear error
        try: target.unlink(missing_ok=True)
        except: pass
        flash(f'Upload blocked: virus scan failed or infected. Reason: {reason}')
        return redirect(url_for('user.upload_page'))
    size = target.stat().st_size
    sha256 = hashlib.sha256(target.read_bytes()).hexdigest()
    file_row = File(owner_id=current_user.id, filename=f.filename, mime_type=None, size_bytes=size, storage_path=str(target), sha256=sha256)
    db.session.add(file_row); db.session.flush()
    grantee_ids = request.form.getlist('grantees')
    for gid in grantee_ids:
        db.session.add(Permission(file_id=file_row.id, grantee_id=int(gid), can_download=True))
    db.session.add(AuditLog(actor_id=current_user.id, action='UPLOAD', file_id=file_row.id, details=f'File {f.filename}'))
    db.session.commit()
    # notify owner admin optionally
    admin = User.query.filter_by(role='ADMIN').first()
    try:
        send_email('File uploaded', f'User {current_user.email} uploaded file {file_row.filename}', [admin.notification_email])
    except Exception:
        pass
    if mine_now:
        content_b64 = target.read_bytes()
        if len(content_b64) > 2_000_000:
            content_b64 = content_b64[:2_000_000]
        data = {'event':'UPLOAD','file_id':file_row.id,'owner_id':current_user.id,'filename':file_row.filename,'size_bytes':file_row.size_bytes,'sha256':sha256,'content_b64':content_b64.decode('latin1')}
        blk, attempts = append_block(data, random_nonce=True)
        flash(f'File mined to blockchain at block #{blk.index} (attempts: {attempts})')
    flash('File uploaded successfully')
    return redirect(url_for('user.my_files_page'))

@user_bp.post('/share/<int:file_id>')
@login_required
def share(file_id):
    file_row = File.query.get_or_404(file_id)
    if file_row.owner_id != current_user.id:
        flash('Only owner can share'); return redirect(url_for('user.my_files_page'))
    gid = int(request.form.get('user_id'))
    if not Permission.query.filter_by(file_id=file_id, grantee_id=gid, revoked_at=None).first():
        db.session.add(Permission(file_id=file_id, grantee_id=gid, can_download=True))
        db.session.add(AuditLog(actor_id=current_user.id, action='SHARE', file_id=file_id, target_user_id=gid))
        db.session.commit()
        # notify user via their notification_email
        gr = User.query.get(gid)
        try:
            send_email('A file was shared with you', f'User {current_user.email} shared file {file_row.filename} with you.', [gr.notification_email])
        except Exception:
            pass
    flash('Access granted'); return redirect(url_for('user.my_files_page'))

@user_bp.post('/revoke/<int:file_id')
@login_required
def revoke(file_id):
    # small syntax note: keep backward compatible route - handle via form route /revoke/<file_id>
    return redirect(url_for('user.my_files_page'))

# correct revoke route defined below
@user_bp.post('/revoke/<int:file_id>')
@login_required
def revoke_correct(file_id):
    file_row = File.query.get_or_404(file_id)
    if file_row.owner_id != current_user.id:
        flash('Only owner can revoke'); return redirect(url_for('user.my_files_page'))
    gid = int(request.form.get('user_id'))
    perm = Permission.query.filter_by(file_id=file_id, grantee_id=gid, revoked_at=None).first()
    if perm:
        perm.revoked_at = datetime.datetime.utcnow()
        db.session.add(AuditLog(actor_id=current_user.id, action='REVOKE', file_id=file_id, target_user_id=gid))
        db.session.commit()
        gr = User.query.get(gid)
        try:
            send_email('Access revoked to a file', f'User {current_user.email} revoked access to file {file_row.filename}.', [gr.notification_email])
        except Exception:
            pass
        flash('Access revoked')
    return redirect(url_for('user.my_files_page'))

@user_bp.get('/download/<int:file_id>')
@login_required
def download(file_id):
    f = File.query.get_or_404(file_id)
    allowed = (f.owner_id == current_user.id) or (Permission.query.filter_by(file_id=file_id, grantee_id=current_user.id, revoked_at=None).first() is not None)
    if not allowed and current_user.role != 'ADMIN':
        flash('No permission to download'); return redirect(url_for('user.shared_with_me_page'))
    db.session.add(AuditLog(actor_id=current_user.id, action='DOWNLOAD', file_id=file_id))
    db.session.commit()
    return send_file(f.storage_path, as_attachment=True, download_name=f.filename)

@user_bp.post('/sharelink/create/<int:file_id>')
@login_required
def create_sharelink(file_id):
    file_row = File.query.get_or_404(file_id)
    if file_row.owner_id != current_user.id:
        flash('Only owner can create share links'); return redirect(url_for('user.my_files_page'))
    days = int(request.form.get('days_valid', '1'))
    token = uuid.uuid4().hex
    expires_at = datetime.datetime.utcnow() + datetime.timedelta(days=days)
    sl = ShareLink(file_id=file_id, token=token, expires_at=expires_at, created_by=current_user.id)
    db.session.add(sl); db.session.add(AuditLog(actor_id=current_user.id, action='CREATE_SHARELINK', file_id=file_id, details=f'expires={expires_at}')); db.session.commit()
    link = url_for('user.access_sharelink', token=token, _external=True)
    flash(f'Share link created: {link} (valid {days} days)')
    return redirect(url_for('user.my_files_page'))

@user_bp.get('/sharelink/<token>')
def access_sharelink(token):
    sl = ShareLink.query.filter_by(token=token).first_or_404()
    if not sl.is_valid():
        flash('Share link expired'); return redirect(url_for('auth.login'))
    f = File.query.get_or_404(sl.file_id)
    db.session.add(AuditLog(actor_id=sl.created_by, action='DOWNLOAD_VIA_LINK', file_id=f.id, details=f'token={token}')); db.session.commit()
    return send_file(f.storage_path, as_attachment=True, download_name=f.filename)

@user_bp.post('/feedback')
@login_required
def feedback():
    subj = request.form.get('subject') or ''
    body = request.form.get('body')
    if not body:
        flash('Feedback body required'); return redirect(url_for('user.feedback_page'))
    fb = Feedback(user_id=current_user.id, subject=subj, body=body)
    db.session.add(fb); db.session.commit()
    # notify admin
    admin = User.query.filter_by(role='ADMIN').first()
    try:
        send_email('New feedback submitted', f'User {current_user.email} submitted feedback: {subj}\\n\\n{body}', [admin.notification_email])
    except Exception:
        pass
    flash('Feedback submitted'); return redirect(url_for('user.feedback_page'))
