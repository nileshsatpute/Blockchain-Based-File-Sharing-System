from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from flask_login import login_required, current_user
from ..models import User, File, Feedback, AuditLog, Block
from .. import db
from ..utils import send_email
import datetime

admin_bp = Blueprint('admin', __name__, template_folder='../templates/admin')

def admin_required():
    return current_user.is_authenticated and current_user.role == 'ADMIN'

@admin_bp.before_request
def check_admin():
    if request.endpoint and request.endpoint.startswith('admin.'):
        if not admin_required():
            return redirect(url_for('auth.admin_login'))

@admin_bp.route('/create_user', methods=['GET'])
@login_required
def create_user_page():
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/create_user.html', users=users)

@admin_bp.post('/users')
@login_required
def create_user():
    email = request.form.get('email')
    username = request.form.get('username') or email.split('@')[0]
    password = request.form.get('password')
    notify_email = request.form.get('notify_email') or email
    if not email or not password:
        flash('Email and password required')
        return redirect(url_for('admin.create_user_page'))
    if User.query.filter_by(email=email).first():
        flash('Email already exists')
        return redirect(url_for('admin.create_user_page'))
    u = User(email=email, username=username, role='USER', active=True, notification_email=notify_email)
    u.set_password(password)
    db.session.add(u)
    db.session.add(AuditLog(actor_id=current_user.id, action='ADMIN_CREATE_USER', target_user_id=u.id))
    db.session.commit()
    # notify user by email with credentials (if SMTP configured)
    try:
        send_email('Account created', f'Your account was created. Email: {email}\\nPassword: {password}', [u.notification_email])
    except Exception:
        pass
    flash('User created and notified (if email configured)')
    return redirect(url_for('admin.create_user_page'))

@admin_bp.route('/change_password', methods=['GET'])
@login_required
def change_password_page():
    users = User.query.filter(User.role != 'ADMIN').all()
    return render_template('admin/change_password.html', users=users)

@admin_bp.post('/users/<int:user_id>/password')
@login_required
def change_user_password(user_id):
    new_pw = request.form.get('new_password')
    u = User.query.get_or_404(user_id)
    u.set_password(new_pw)
    db.session.add(AuditLog(actor_id=current_user.id, action='ADMIN_CHANGE_PASSWORD', target_user_id=u.id))
    db.session.commit()
    try:
        send_email('Password changed', f'Your password was changed by admin. New password: {new_pw}', [u.notification_email])
    except Exception:
        pass
    flash('Password updated and user notified (if email configured)')
    return redirect(url_for('admin.change_password_page'))

@admin_bp.route('/all_files', methods=['GET'])
@login_required
def all_files_page():
    files = File.query.order_by(File.created_at.desc()).all()
    return render_template('admin/all_files.html', files=files)

@admin_bp.get('/files/<int:file_id>/download')
@login_required
def admin_download(file_id):
    f = File.query.get_or_404(file_id)
    return send_file(f.storage_path, as_attachment=True, download_name=f.filename)

@admin_bp.route('/feedback', methods=['GET'])
@login_required
def feedback_page():
    feedbacks = Feedback.query.order_by(Feedback.created_at.desc()).all()
    return render_template('admin/feedback.html', feedbacks=feedbacks)

@admin_bp.post('/feedback/<int:fb_id>/reply')
@login_required
def reply_feedback(fb_id):
    fb = Feedback.query.get_or_404(fb_id)
    reply = request.form.get('reply')
    fb.admin_reply = reply
    fb.status = 'CLOSED'
    db.session.add(fb)
    db.session.add(AuditLog(actor_id=current_user.id, action='ADMIN_REPLY_FEEDBACK', target_user_id=fb.user_id, details=reply))
    db.session.commit()
    user = User.query.get(fb.user_id)
    try:
        send_email(f"Reply to your feedback #{fb.id}", f"Admin reply:\\n\\n{reply}", [user.notification_email])
    except Exception:
        pass
    flash('Replied and user notified (if email configured)')
    return redirect(url_for('admin.feedback_page'))

@admin_bp.route('/logs', methods=['GET'])
@login_required
def logs_page():
    from ..models import AuditLog
    logs = AuditLog.query.order_by(AuditLog.created_at.desc()).all()
    return render_template('admin/logs.html', logs=logs)

@admin_bp.route('/chain', methods=['GET'])
@login_required
def chain_page():
    blocks = Block.query.order_by(Block.index.desc()).limit(200).all()
    return render_template('admin/chain.html', blocks=blocks)
