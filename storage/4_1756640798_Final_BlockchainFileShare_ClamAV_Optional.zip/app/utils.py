import os, smtplib, socket, logging
from email.message import EmailMessage
from dotenv import load_dotenv
load_dotenv()
logger = logging.getLogger(__name__)

def send_email(subject, body, to_addrs):
    host = os.environ.get('SMTP_HOST')
    port = int(os.environ.get('SMTP_PORT', '587')) if os.environ.get('SMTP_PORT') else None
    user = os.environ.get('SMTP_USER')
    pwd = os.environ.get('SMTP_PASS')
    from_addr = os.environ.get('FROM_EMAIL', user)
    if not host or not from_addr:
        logger.info("SMTP not configured; email skipped. Subject=%s To=%s", subject, to_addrs)
        return False
    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = ", ".join(to_addrs) if isinstance(to_addrs, (list,tuple)) else to_addrs
        msg.set_content(body)
        with smtplib.SMTP(host, port, timeout=10) as s:
            s.starttls()
            if user and pwd:
                s.login(user, pwd)
            s.send_message(msg)
        logger.info("Email sent: %s -> %s", subject, to_addrs)
        return True
    except (smtplib.SMTPException, socket.error) as e:
        logger.exception("Failed to send email: %s", e)
        return False

def clamav_scan(path):
    \"\"\"Scan file using clamd. Requires clamd running and python-clamd installed.
    Returns (True, '') if clean. Returns (False, reason) if infected or clamd unavailable.
    \"\"\"
    try:
        import clamd
    except Exception as e:
        return False, f\"clamd python client not installed: {e}\"
    try:
        cd = clamd.ClamdUnixSocket() if hasattr(clamd, 'ClamdUnixSocket') else clamd.ClamdNetworkSocket()
        res = cd.scan(path)
        if not res:
            return False, \"clamd returned no result\"
        entry = list(res.values())[0]
        status = entry[0].upper()
        if status == 'OK' or status == 'CLEAN' or status == 'NOTFOUND':
            return True, ''
        return False, f'Infected: {entry[1]}'
    except Exception as e:
        return False, f'clamd error: {e}'


import clamd
import os

def scan_file_with_clamav(file_path):
    try:
        cd = clamd.ClamdNetworkSocket(host='127.0.0.1', port=3310)
        cd.ping()
        result = cd.scan(file_path)
        if result:
            status = result[file_path][0]
            if status == 'FOUND':
                virus_name = result[file_path][1]
                return False, f"Virus detected: {virus_name}"
        return True, "Clean"
    except Exception as e:
        # Skip scan if ClamAV is not available
        return True, f"Skipped scan (ClamAV not available: {e})"

